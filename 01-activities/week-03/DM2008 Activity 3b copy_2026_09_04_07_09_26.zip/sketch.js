// DM2008 — Activity 3b
// One Function Wonder (30 min)
//
// Write a function that draws a shape or group of shapes.
// It should take at least one parameter — try x, y, size, or color.
// Call it several times with different values to create variation.
//
// Ideas: a simple face, a flower, a house, an icon.
// Example: myShape(100, 200, 50); myShape(300, 200, 80);
//
// Stretch: call your function inside a for loop to create a repeating pattern.
let x;
let y;
let a;
let b;

let xR;
let xA;
let yR;
let yA;

let aA;

let bA;
let start;
let stop;

let speed = 0;
function setup() {
  createCanvas(400, 400);
  rectMode(CENTER);
}

function draw() {
  background(220);

  speed += 0.05;
  for (let i = 0; i < width; i += 100) {
    for (let j = 0; j < height; j += 100) {
      if ((i + j) % 200 == 0) {
        myShape(i + 50, j + 50, i + 50, j + 100, speed);
      } else {
        stripes(i + 50, j + 50, 100, 100);
      }
    }
  }

  //noStroke();
}

// Define your function outside draw()
// It can be called from anywhere in your sketch

function myShape(xR, yR, xA, yA, speed) {
  push();

  translate(xR, yR);
  rectMode(CENTER);
  rotate(speed);
  speed += 0.05;

  noStroke();
  fill(93, 159, 24);

  rect(0, 0, 100, 100);

  pop();

  push();
  translate(xA,yA-50);
  rotate(speed);
  speed += 0.05;
  noStroke();
  fill(234, 231, 12);
  arc(0, 50, 100, 100, PI, 2 * PI);
  fill(132, 238, 84);
  arc(0,-50, 100, 100, 0, PI);
  pop();
}

function stripes(x, y, a, b) {
  noStroke();
  fill(234, 153, 143);
  rect(x, y, a, b);
  fill(242, 111, 54);
  ellipse(x, y, a);
  fill(214, 94, 139);
  ellipse(x, y, a / 2);
}
function keyPressed() {
  saveCanvas("Activity3b_picture", "png");
}

// DM2008 — Activity 2a
// Mode Switch (20 min)
//
// Use keys 1, 2, 3 to switch between at least 3 modes.
// Each mode should change more than just the background — think fill, size, or motion.
//
// Stretch: add a 4th mode, or make the ellipse change shape between modes.

let x = 0;  // ellipse x-position
let y= 200;
let size = 50;   // ellipse size
let bgColor;     // background color, changed by key presses
let col;
let sizeR=10;
let yR=0;
let xR=0;


function setup() {
  createCanvas(400, 400);
  bgColor = color(220);
}

function draw() {
  background(bgColor);

  fill(col);
  ellipse(x, y, size);
  rect(xR,yR,sizeR);

  x += 2;

  if (x > width + size / 2) {
    x = 0;
  }
  if (x > width /2){
  size=random(50,150);
} else {
    size= random(0,50);
}
  
}

// Keys 1, 2, 3 change the background color
function keyPressed() {
  switch (key) {
    case "1":
      bgColor = color(200, 100, 100);
      col=color(231,176,45);
      break;
    case "2":
      bgColor = color(100, 200, 100);
      y= random(50,200);
    case "3":
      bgColor = color(100, 100, 200);
      xR++;
      yR++;
      break; 
    case "4":
      col=random(255);
    default:
      bgColor = color(220); 
  }
}

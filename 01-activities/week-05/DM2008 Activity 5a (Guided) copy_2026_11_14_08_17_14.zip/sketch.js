// DM2008 — Activity 5a [Guided]
// Colliding Circles (30 min)
//
// A vector stores position and movement together — cleaner than separate x and y variables.
// Your job is to get two balls moving, then detect and respond to their collision.
//
// Suggested order:
// 1. Create two Ball objects in setup()
// 2. Check the distance between them in draw()
// 3. Trigger a visual response when they collide
// 4. Implement edge behaviour in move() — wrap or bounce, your choice
//
// Stretch: add a third ball, or make the collision response affect both balls.

let balls = [];

function setup() {
  createCanvas(400, 400);
  // Create two balls at different starting positions
  balls.push(new Ball(100, 200));
  balls.push(new Ball(300, 200));
  balls.push(new Ball(400, 230));
}

function draw() {
  background(230);

  // Check collision between the two balls
  // dist() measures the distance between their centers
  // They overlap when that distance is less than the sum of their radii

  let d = dist(balls[0].pos.x, balls[0].pos.y, balls[1].pos.x, balls[1].pos.y); //0 is itself and 1 is other, damit geschaut wird dass man nicht sich selber als gegner sieht
  let colliding = d < balls[0].r + balls[1].r; // true when the balls overlap, false otherwise

  for (let i = 0; i < balls.length; i++) {
    balls[i].move();
    balls[i].show(colliding);
    balls[i].checkCollision(balls);
  }
}

class Ball {
  constructor(x, y) {
    // pos and vel are vectors — they store x and y together as one object
    this.pos = createVector(x, y);
    this.vel = createVector(random(-1, 2), random(-2, 3));
    this.r = 30;
  }

  move() {
    // Adding the velocity vector to position moves the ball each frame
    this.pos.add(this.vel);

    // Handle edges — could you make this bounce instead of wrap?
    if (this.pos.x > width) {
      this.pos.x = 0;
    }
    if (this.pos.x < 0) {
      this.pos.x = width;
    }
    if (this.pos.y > height) {
      this.pos.y = 0;
    }
    if (this.pos.y < 0) {
      this.pos.y = height;
    }
  }

  show(colliding) {
    // colliding is true or false — try using it in an if/else to change fill or size

    noStroke();
    fill(random(255),random(255),random(255));
    ellipse(this.pos.x, this.pos.y, this.r * 2);
  }

  checkCollision(others) {
    for (let i = 0; i < others.length; i++) {
      

      if (others[i] !== this) {
        let other = others[i];

        let d = dist(this.pos.x, this.pos.y, other.pos.x, other.pos.y);

        if (d < this.r + other.r) {
         
          stroke(10);
          rect(this.pos.x-this.r, this.pos.y-this.r, this.r * 2);
        
          
        }
      }
    }
  }
}

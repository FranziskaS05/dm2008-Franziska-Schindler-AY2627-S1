// DM2008 — Activity 1b [Ryoji Ikeda]
// Learning By Making (30 min)

let x;
let y;
let w;
let a =234;
let b=45;
let c=255;

function setup() {
  createCanvas(800, 400);
  background(255);
  noStroke();
  fill(0);
  keyPressed();
}

function draw() {
  background(255,0);
  
  x = random(width);
  w = random(1, 45);
  
  
  fill(random(a),random(b),random(c));
  rect(x, 0, w, random(height));
  
  
  x = random(width);
  rect(x, height/2, w, height/2);  
  fill(random(255),random(200),random(165));
  ellipse(x,mouseY,random(100));

  
}

function keyPressed() {
  
  saveCanvas("activity1b-image", "png");         
       
 
}
function mousePressed(){
 a=random(255);
    b= random(255);
    c=random(255);
}


